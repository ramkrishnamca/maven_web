echo "[win]" >> inventory.txt
echo "$common_server" >> inventory.txt
echo "" >> inventory.txt
echo "[win:vars]" >> inventory.txt
echo "ansible_port=5986" >> inventory.txt
echo "ansible_connection=winrm" >> inventory.txt
echo "ansible_winrm_server_cert_validation=ignore" >> inventory.txt
echo "ansible_winrm_transport=credssp" >> inventory.txt
echo "ansible_winrm_credssp_disable_tlsv1_2=true" >> inventory.txt
echo "$Server_Name"  > /var/lib/jenkins/workspace/ORT/server.txt

