﻿#$tagList = Import-Csv -Path "tags.csv"
#$servers = Get-Content "server.txt"

$tagList = Import-Csv -Path C:\temp\ORT_capture\tags.csv
$servers = Get-Content -Path C:\temp\ORT_capture\server.txt

$outputCSV = "C:\temp\ORT_capture\ORTReport.csv"     
$ErrorActionPreference = "Stop"

function FirewallStatus ([string]$computer = $env:computername)
{ $FirewallStatus=$null
    try
    {   
       $FirewallSts=$null
 
        $HKLM = 2147483650 
        $reg = get-wmiobject -list -namespace root\default -computer $computer | where-object { $_.name -eq "StdRegProv" }
        $firewallEnabled = $reg.GetDwordValue($HKLM, "System\ControlSet001\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile","EnableFirewall")

        if([bool]($firewallEnabled.uValue))
        {
            $FirewallStatus = 'Domain-ON'
        }
        else
        {
            $FirewallStatus = 'Domain-OFF'
        }
	$OFS = "`r`n"
	If($FirewallSts){$FirewallSts+=$OFS+$FirewallStatus} else {$FirewallSts=$FirewallStatus}
        #---------------
	$reg = get-wmiobject -list -namespace root\default -computer $computer | where-object { $_.name -eq "StdRegProv" }
        $firewallEnabled = $reg.GetDwordValue($HKLM, "SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile","EnableFirewall")

        if([bool]($firewallEnabled.uValue))
        {
            $FirewallStatus = 'Public-ON'
        }
        else
        {
            $FirewallStatus = 'Public-OFF'
        }
        $OFS = "`r`n"
	If($FirewallSts){$FirewallSts+=$OFS+$FirewallStatus} else {$FirewallSts=$FirewallStatus}
        #---------------
        
	$reg = get-wmiobject -list -namespace root\default -computer $computer | where-object { $_.name -eq "StdRegProv" }
        $firewallEnabled = $reg.GetDwordValue($HKLM, "SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile","EnableFirewall")

        if([bool]($firewallEnabled.uValue))
        {
            $FirewallStatus = 'Private-ON'
        }
        else
        {
            $FirewallStatus = 'Private-OFF'
        }
	$OFS = "`r`n"
	If($FirewallSts){$FirewallSts+=$OFS+$FirewallStatus} else {$FirewallSts=$FirewallStatus}
        #---------------
    }
    catch
    {
        $FirewallSts="Error"
    }
    return $FirewallSts
}

Function SCCMStatus([string]$computer = $env:computername)
{ $SccmStatus=$mull
    $Client_Status = $null
    $machine_Rstatus = $null
    try
    {
        If(Get-Service -ComputerName $computer -Name CcmExec)
        {
            $Client_Status = "Yes"
            $MachinePolicyRetrievalEvaluation = "{00000000-0000-0000-0000-000000000021}"
	        $SoftwareUpdatesScan = "{00000000-0000-0000-0000-000000000113}"
	        $SoftwareUpdatesDeployment = "{00000000-0000-0000-0000-000000000108}"

	        #################### check if Scan cycles are working ###################
	        $machine_status = Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule $MachinePolicyRetrievalEvaluation -ComputerName $computer
	        $software_status = Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule $SoftwareUpdatesScan -ComputerName $computer
	        $softwaredeploy_Status = Invoke-WmiMethod -Namespace root\ccm -Class sms_client -Name TriggerSchedule $SoftwareUpdatesDeployment -ComputerName $computer

            if($machine_status -and $software_status -and $softwaredeploy_Status)
	        {
		        $machine_Rstatus = "Successful"
	        } 
        }
        If(($Client_Status -eq 'Yes') -and ($machine_Rstatus -eq 'Successful'))
        {
            $SccmStatus = "Installed"
        }
        else
        {
            $SccmStatus = "Not Installed"
        }
    }
    catch
    {
        $errorMessage = $error[0].Exception.Message
        $SccmStatus = "Error - Unable to fetch. $errorMessage"
    }
    return $SccmStatus
}

function AntivirusStatus([string]$computer = $env:computername)
{ $antivirusStatus=$null
    try{
               
         [uint32]$hklm = 2147483650
         $wmi = get-wmiobject -list "StdRegProv" -namespace root\default -computername $computer
                                
         $key = "SOFTWARE\Symantec\Symantec Endpoint Protection\CurrentVersion\public-opstate"
         $value = "LatestVirusDefsDate"

         $antiv=($wmi.GetStringValue($hklm,$key,$value)).svalue
         if (!$antiv) { $antivirusStatus="Not Installed" }  else {$antivirusStatus="Installed(Def_date: $antiv)"}                      
                } catch { $antivirusStatus="Antivirus Not found"
                }
    return $antivirusStatus
} 

function DomainJoinStatus([string]$computer = $env:computername)
{ $domainConnected=$null
    try
    {
        $compSystInfo = Get-WmiObject win32_computersystem -ComputerName $computer
        if ($compSystInfo.partofdomain -eq $true)
        {
            $domainConnected = $compSystInfo.Domain
        }
        else
        {
            $domainConnected = "Red"
        }
    }
    catch
    {
        $errorMessage = $error[0].Exception.Message
        $domainConnected = "Error - Unable to fetch. $errorMessage"
    }
    return $domainConnected
}


###---------------------------------------------------------
function PatchStatus ([string]$computer = $env:computername){ $PatchStatusout=$null
Try{    
    $TotalPatches=$null  
    $TotalPatches = Get-WmiObject -Class Win32_ReliabilityRecords -ComputerName $computer -Filter "SourceName = 'Microsoft-Windows-WindowsUpdateClient'"  -ErrorAction stop
    if  ($TotalPatches) {    
    $LatestPatchDate1 = $TotalPatches | Select-Object @{LABEL = "Date";EXPRESSION = {$_.ConvertToDateTime($_.TimeGenerated)}}, TimeGenerated | Sort-Object Date | select -first 1
    $LatestPatchDate2 = $TotalPatches | Select-Object @{LABEL = "Date";EXPRESSION = {$_.ConvertToDateTime($_.TimeGenerated)}}, TimeGenerated | Sort-Object Date | select -last 1
    if (($LatestPatchDate1.date).CompareTo(($LatestPatchDate2.date)) -le '0'){$LatestPatchDate=$LatestPatchDate2} else {$LatestPatchDate=$LatestPatchDate1}
   
    $dispLatestDate = get-date $(($LatestPatchDate).date) -Format 'MM/dd/yyyy'
    $ConvertDate = ($LatestPatchDate.TimeGenerated).Substring(0,8)
    
    $LatestPatches = $TotalPatches | where {$_.TimeGenerated -like "$ConvertDate*"} | Select-Object @{LABEL = "Date";EXPRESSION = {$_.ConvertToDateTime($_.TimeGenerated)}}, ProductName , Message
    
    $Failure = (($LatestPatches | Where { $_.message -match 'failure' }).Date).Count    
    $successful = (($LatestPatches | Where { $_.message -match 'Installation Successful:' }).Date).Count    
    $TotPatchCount = ($LatestPatches.Date).count
       			$ValidDays = get-date ((get-date).AddDays(-15)) -format 'MM/dd/yyyy'
                        if ($dispLatestDate -ge $ValidDays){
                            $PatchStatusout="$dispLatestDate  $successful Patches Installed"
                            }
                            else {PatchStatusout="$dispLatestDate $successful Patches Installed  CODE:RED"
                             }      
    }
    }
    Catch {

 $TotalPatches =$null
    $TotalPatches = Get-WinEvent -ComputerName $computer  -FilterHashtable @{logname=’System’; providerName='Microsoft-Windows-WindowsUpdateClient'} -ErrorAction stop | where-object {($_.id -eq 19) -or ($_.id -eq 20)} | Select-object Timecreated, ID  -ErrorAction stop
#---------------------    
 
        if  ($TotalPatches) {

            $LatestPatchDate1 = $TotalPatches | Sort-Object Timecreated | select -first 1
            $LatestPatchDate2 = $TotalPatches | Sort-Object Timecreated | select -last 1
      
                if (($LatestPatchDate1.Timecreated).CompareTo(($LatestPatchDate2.Timecreated)) -le '0'){$LatestPatchDate=$LatestPatchDate2} else {$LatestPatchDate=$LatestPatchDate1}
      
                $dispLatestDate = get-date $(($LatestPatchDate).Timecreated) -Format 'MM/dd/yyyy'

                $LatestPatches = $TotalPatches | where {$_.Timecreated -like "$dispLatestDate*"} 
                $Failure = (($LatestPatches | Where { $_.id -match '20' }).ID).Count
                $successful = (($LatestPatches | Where { $_.id -match '19' }).ID).Count
                $TotPatchCount = ($LatestPatches.ID).count
                $ValidDays = get-date ((get-date).AddDays(-15)) -format 'MM/dd/yyyy'
                        if ($dispLatestDate -ge $ValidDays){
                            $PatchStatusout="$dispLatestDate  $successful Patches Installed"
                            }
                            else {PatchStatusout="$dispLatestDate $successful Patches Installed  CODE:RED"
                             }    
            }
    }
if(!$PatchStatusout) {$PatchStatusout= "no patches"}
return $PatchStatusout
}

###---------------------------------------------------------

####--------------------------------------------------------
function NTPStatus([string]$computer = $env:computername) {$time=$Null
    
          try{
    
                 $time=$null
                 [uint32]$hklm = 2147483650
                 $key = "SYSTEM\CurrentControlSet\services\W32Time\Parameters"
                 $value = "NtpServer"
                 $wmi = get-wmiobject -list "StdRegProv" -namespace root\default  -computername $computer
                 $time1=($wmi.GetStringValue($hklm,$key,$value)).svalue
                 $tp=$time1 -split ","
                 $time=$tp[0]
                 If ($time) { $time=$time} else {$time ="No Sever"}
                 }Catch {
                  
                  $time= "error"
                 }
    return $time
}
####--------------------------------------------------------

#####-------------------------------------------------------
function fqdn([string]$computer = $env:computername) {$fqdn=$Null
        try{

                $fqdn = (Get-WmiObject -Class win32_computersystem -ComputerName $computer   ).DNSHostName+"."+(Get-WmiObject -ComputerName $computer win32_computersystem).Domain
                if (!$fqdn){ $fqdn="Fail"}
            
            }Catch{ $fqdn="Error"                
                            
            } 
  return $fqdn 
} 

#####-------------------------------------------------------

function IPAddress([string]$computer = $env:computername) {$IPS=$Null
        try{
                $IP = (Get-WmiObject -Class win32_networkadapterconfiguration -ComputerName $computer  | select ipaddress ).ipaddress -replace "/S",  ","
                $IPS = ($IP -JOIN ' ').Trim()
                if (!$IPS){$IPS="Fail"}
            }Catch {
                $IPS="Error"
            }
   return $IPS
}
######------------------------------------------------------

function hddvol([string]$computer = $env:computername) { $diskSpace=$Null
            try{

                $Disks = gwmi win32_logicaldisk -ComputerName $computer | Where-Object {$_.DriveType -eq '3' -or $_.DriveType -eq '4' } | select DeviceID, @{n='FreeSpace';e={$_.Freespace/ 1GB}}, @{n='Size';e={$_.Size/ 1GB}}
                $diskSpace = $null
                $diskSpace = @()
                $disk_count = $Disks.count
                foreach ($disk in $Disks){

                    [String]$id = $disk.DeviceID
                    [string]$fs = $disk.FreeSpace
                    [string]$Dsize = $disk.Size
                    $FreeSpace = [math]::Round($fs,2)
                    $Size = [math]::Round($Dsize,2)
                    $diskSpace += "$id ($Size GB Size)"
                    } 
         }Catch {
             $diskSpace="Error"
         }
    return $diskSpace
}
######-----------------------------------------------------------
function LocalAdminGroupMembers([string]$computer = $env:computername){ $LocalAdminMem=$Mems=$null
         
    try {$groupname="Administrators"
	$group =[ADSI]"WinNT://$computer/$groupname"     
	$members = @($group.psbase.Invoke("Members"))
	$OFS = "`r`n"
	Foreach ($m in $members) {
	If($Mems){$Mems+=$OFS+$m.GetType().InvokeMember("Name", 'GetProperty', $null, $m, $null)} else {$Mems=$m.GetType().InvokeMember("Name", 'GetProperty', $null, $m, $null)}
	}
	$LocalAdminMem=$Mems
     }
     
     Catch {
       $LocalAdminMem ="Error"
        }
    return $LocalAdminMem
}

###-----------------------------------------------------------
######-----------------------------------------------------------
function SplunkStatus([string]$computer = $env:computername){ $splunksts=$splunkag=$null

                  try{
                  $splunkag =  (Get-WmiObject Win32_Service -ComputerName $computer  | Where-Object { $_.Name -eq 'SplunkForwarder'}).state                
                  if ($splunkag) {
                                        if ($splunkag -match 'running') {
                                              $splunksts="Installed"
			                } else {
				 	$splunksts="Not Running" }
			      
                    } else { $splunksts="Not Installed"}
                   } catch { $splunksts="Error"}

    return $splunksts
}

#############-----------------------------------------------------

function HDDEncryption([string]$computer = $env:computername) {
    
    try{
                try {
			$Content = manage-bde -computername $computer -status c:
                        $ContentManage = $Content.ToString()
                        $ContentManageStatus = ($ContentManage | Select-String 'Lock Status').ToString().Trim().Substring(12).Trim()
                                
                                if ($ContentManageStatus -eq 'Unlocked'){
                                    $HDDEncrysts="No HDD Encryption"
                                    }
                                else {$HDDEncrysts="HDD Encrypted"}
                                }
                    
                    catch{
                    
                           $BitlockerService = gwmi win32_service -ComputerName $computer | where name  -eq "BDESVC" 
                                
                                    if ($BitlockerService.state -eq "Running"){
                                        $HDDEncrysts="HDD Encrypted"
                                      }elseif ($BitlockerService.state -eq "Stopped"){
                                        $HDDEncrysts="BitLocker Service not running"
                                       } else {$HDDEncrysts="No HDD Encryption"}
                    
                     }

	    }Catch {$HDDEncrysts="No HDD Encryption"}
      return $HDDEncrysts
   }
#------------------------------------------------------------------------------------------
    $finalOutput = @()
    Foreach ($server in $servers) 
    {
        $outObject = New-Object -TypeName PSObject
        $outObject|Add-Member -MemberType NoteProperty -Name "Servername" -Value $server
        Foreach($tag in $tagList)
        {
            if($tag.flag -eq 'yes')
            {    
                switch($tag.Checkname)
                {    
                    SCCMStatus{
                        $lastStatus = "Collecting SCCM Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(SCCMStatus $server)
                    } #SCCM working fine or not 
                    AntivirusStatus{
                        $lastStatus = "Collecting Antivirus Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(AntivirusStatus $server)                    
                    } #Antivirus
                    FirewallStatus{
                        $lastStatus = "Collecting Firewall Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(FirewallStatus $server)
                    }#Firewall enable or Disable status
                    DomainJoinStatus{                    
                        $lastStatus = "Collecting Domain Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(DomainJoinStatus $server)
                    }## Machine added to domain 
                    PatchStatus{
                        $lastStatus = "Collecting Patch Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(PatchStatus $server)
                    } #PatchStatus working fine or not 
                    NTPStatus{
                        $lastStatus = "Collecting NTP Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(NTPStatus $server)
                    } #NTPStatus working fine or not 
                    fqdn{
                        $lastStatus = "Collecting fqdn Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(fqdn $server)
                    } #fqdn working fine or not                     
                    IPAddress{
                        $lastStatus = "Collecting IPAddress Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(IPAddress $server)
                    } #IPAddress working fine or not 
                        hddvol{
                        $lastStatus = "Collecting hddvol Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(hddvol $server)
                    } #Ihddvol working fine or not 
                        LocalAdminGroupMembers{
                        $lastStatus = "Collecting LocalAdminGroupMembers Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(LocalAdminGroupMembers $server)
                    } #LocalAdminGroupMembers working fine or not 
                        SplunkStatus{
                        $lastStatus = "Collecting Splunk Agent Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(SplunkStatus $server)
                    } #SplunkStatusworking fine or not 
                        HDDEncryption{
                        $lastStatus = "Collecting HDDEncryption Status"
                        Write-Progress -Activity "Windows ORT" -Status $lastStatus
                        $outObject|Add-Member -MemberType NoteProperty -Name $tag.Checkname -Value $(HDDEncryption $server)
                    } #HDDEncryption fine or not 
                }
                
            }
        }
        $finalOutput += $outObject
    }
    $finalOutput | ConvertTo-Csv -NoTypeInformation | Out-File -FilePath $outputCSV  -Force -Encoding utf8

#------------------------------------------------------------------------------------------------------------------------




